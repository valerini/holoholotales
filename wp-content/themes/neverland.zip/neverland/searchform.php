<form name="search_form" method="get" action="<?php echo esc_url(home_url('/')); ?>" class="search_form">
    <input type="text" name="s" placeholder="<?php _e('Search', 'gt3_theme_localization'); ?>" value="">
    <input type="submit" value="<?php _e('Search The Site', 'gt3_theme_localization'); ?>">
</form>