<?php
if (is_active_sidebar('page-sidebar-2')) {
    dynamic_sidebar("Footer");
}